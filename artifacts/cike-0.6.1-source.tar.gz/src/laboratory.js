const design = window.CikeAppearance,
  api = window.cike;
const $ = (id) => document.getElementById(id);
let current = design.defaults(),
  baseline = design.defaults(),
  saved = design.defaults(),
  revision = 0;
const names = { paper: "小纸团", round: "圆团子", bean: "软豆子" };
const data = (a) =>
  "data:image/svg+xml;charset=utf-8," + encodeURIComponent(design.svg(a));
for (const key of Object.keys(design.presets))
  $("preset-" + key).src = data(design.presets[key]);
function note(a) {
  return `${names[a.shape]} · ${["原位", "下移一点", "再下移一点"][a.face]} · ${["点点眼", "圆一点", "再大一点"][a.eyes]}`;
}
async function render() {
  const version = ++revision;
  for (const k of ["shape", "face", "eyes", "expression"])
    $(k).value = current[k];
  $("face-value").textContent = ["原位", "下移一点", "再下移一点"][
    current.face
  ];
  $("eyes-value").textContent =
    current.expression === "smile"
      ? ["点点眼", "圆一点", "再大一点"][current.eyes]
      : "弯眼宽度";
  $("before").src = data(baseline);
  $("after").src = data(current);
  $("before-note").textContent = note(baseline);
  $("after-note").textContent = note(current);
  document
    .querySelectorAll("[data-preset]")
    .forEach((el) =>
      el.setAttribute(
        "aria-pressed",
        JSON.stringify(current) ===
          JSON.stringify(design.presets[el.dataset.preset]),
      ),
    );
  try {
    const src = await api.call("art", {
      illustration: "water",
      night: $("night").checked,
      appearance: current,
    });
    if (version === revision) $("scene").src = src;
  } catch (e) {
    $("status").textContent = e.message;
  }
}
for (const k of ["shape", "face", "eyes", "expression"])
  $(k).addEventListener("input", () => {
    current = {
      ...current,
      [k]: ["face", "eyes"].includes(k) ? Number($(k).value) : $(k).value,
    };
    $("status").textContent = "这是预览，桌面还没有改变。";
    render();
  });
$("night").onchange = render;
document.querySelectorAll("[data-preset]").forEach(
  (el) =>
    (el.onclick = () => {
      current = { ...design.presets[el.dataset.preset] };
      $("status").textContent = "选好起点后，试着只改一个地方。";
      render();
    }),
);
$("baseline").onclick = () => {
  baseline = { ...current };
  $("status").textContent = "A 已固定。现在只动一个开关，观察 B 的变化。";
  render();
};
async function apply(a) {
  $("apply").disabled = true;
  $("restore").disabled = true;
  try {
    const s = await api.call("appearance", a);
    saved = { ...s.appearance };
    current = { ...saved };
    await render();
    $("status").textContent = "已经住到桌面上了。提醒里的角色也会一起变化。";
  } catch (e) {
    $("status").textContent = e.message;
  } finally {
    $("apply").disabled = false;
    $("restore").disabled = false;
  }
}
$("apply").onclick = () => apply(current);
$("restore").onclick = () => apply(design.defaults());
api
  .call("get")
  .then((s) => {
    saved = s.appearance || design.defaults();
    current = { ...saved };
    baseline = { ...saved };
    render();
  })
  .catch((e) => {
    $("status").textContent = e.message;
  });
