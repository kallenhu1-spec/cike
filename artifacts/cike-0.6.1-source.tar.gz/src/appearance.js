// Shared, deterministic vector design. No generated code or remote content.
(function (root) {
  const defaults = () => ({
    shape: "paper",
    face: 0,
    eyes: 0,
    expression: "smile",
  });
  const presets = {
    paper: { ...defaults() },
    round: { shape: "round", face: 2, eyes: 1, expression: "smile" },
    bean: { shape: "bean", face: 1, eyes: 0, expression: "sleepy" },
  };
  function validate(a) {
    if (
      !a ||
      !["paper", "round", "bean"].includes(a.shape) ||
      !Number.isInteger(a.face) ||
      a.face < 0 ||
      a.face > 2 ||
      !Number.isInteger(a.eyes) ||
      a.eyes < 0 ||
      a.eyes > 2 ||
      !["smile", "happy", "sleepy"].includes(a.expression)
    )
      throw Error("形象参数无效");
    return {
      shape: a.shape,
      face: a.face,
      eyes: a.eyes,
      expression: a.expression,
    };
  }
  function isOriginal(a) {
    return JSON.stringify(validate(a)) === JSON.stringify(defaults());
  }
  function inner(input) {
    const a = validate(input),
      y = 111 + a.face * 5,
      eye = 3 + a.eyes * 0.8;
    const bodies = {
      paper:
        "M56 155C30 136 42 100 52 84C43 62 58 39 82 44C93 24 121 25 135 42C167 33 189 53 181 82C203 111 193 148 170 159C153 179 74 183 56 155Z",
      round:
        "M38 123C37 75 64 34 110 34C158 34 187 77 186 123C185 158 164 178 111 178C61 178 39 160 38 123Z",
      bean: "M32 132C30 100 52 68 89 72C98 37 129 36 151 60C181 73 197 106 191 139C188 169 156 181 109 178C59 184 32 164 32 132Z",
    };
    const eyes =
      a.expression === "sleepy"
        ? `<path d="M${82 - eye} ${y}q${eye + 4} 6 ${eye * 2 + 8} 0M${129 - eye} ${y}q${eye + 4} 6 ${eye * 2 + 8} 0" fill="none"/>`
        : a.expression === "happy"
          ? `<path d="M${82 - eye} ${y}q${eye + 4} -9 ${eye * 2 + 8} 0M${129 - eye} ${y}q${eye + 4} -9 ${eye * 2 + 8} 0" fill="none"/>`
          : `<ellipse cx="86" cy="${y}" rx="${eye}" ry="${eye + 1}" fill="#756a55" stroke="none"/><ellipse cx="137" cy="${y}" rx="${eye}" ry="${eye + 1}" fill="#756a55" stroke="none"/>`;
    return `<ellipse cx="110" cy="191" rx="55" ry="8" fill="#645d48" opacity=".10"/><g stroke="#756a55" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="${bodies[a.shape]}" fill="#fff9e8"/>${a.shape === "paper" ? '<path d="M66 56L81 64M151 51L145 61M49 123L59 120M169 145L176 148" opacity=".24"/>' : ""}<path d="M72 165Q66 185 83 181M145 168Q152 185 163 176" fill="#fff9e8"/><path d="M51 126Q36 116 34 129M180 128Q195 117 195 130" fill="none"/>${eyes}<path d="M105 ${y + 11}Q111 ${y + 17} 117 ${y + 11}" fill="none"/><path d="M95 38Q109 17 128 28Q117 44 95 38Z" fill="#b7c5a0"/><path d="M99 36L116 30" stroke-width="1.3"/></g><ellipse cx="73" cy="${y + 11}" rx="10" ry="5" fill="#eac0b0" opacity=".65"/><ellipse cx="150" cy="${y + 11}" rx="10" ry="5" fill="#eac0b0" opacity=".65"/>`;
  }
  function svg(a) {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="210" viewBox="0 0 220 210">${inner(a)}</svg>`;
  }
  const api = { defaults, presets, validate, isOriginal, inner, svg };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.CikeAppearance = api;
})(typeof window !== "undefined" ? window : globalThis);
