const { contextBridge, ipcRenderer } = require("electron");
const allowed = [
  "get",
  "voice-silent", "voice-reference-text", "voice-room", "voice-summary", "voice-engine", "voice-lines", "voice-settings", "voice-preview", "voice-play", "voice-save", "voice-approve", "voice-delete", "voice-generate", "voice-cancel", "voice-microphone", "voice-clear",
  "request",
  "art",
  "appearance",
  "laboratory",
  "studio",
  "motion-library",
  "moment",
  "preview",
  "hold",
  "menu",
  "save",
  "prompt",
  "import",
  "clear-custom",
  "export",
  "reset",
  "drag-start",
  "drag",
  "drag-end",
  "passthrough",
];
contextBridge.exposeInMainWorld("cike", {
  call: async (name, value) => {
    if (!allowed.includes(name)) throw Error("未知操作");
    const r = await ipcRenderer.invoke(name, value);
    if (!r.ok) throw Error(r.error);
    return r.value;
  },
  on: (name, fn) => {
    if (!["state", "speak", "hide-bubble", "voice-changed"].includes(name)) return;
    const listener = (_event, value) => fn(value);
    ipcRenderer.on(name, listener);
    return () => ipcRenderer.removeListener(name, listener);
  },
});
